Check correct pack format for your game version here:
	https://minecraft.fandom.com/wiki/Pack_format